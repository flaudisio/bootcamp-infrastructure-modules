def handler(event, context):
    print("Hi! This is the initial \"dummy\" code deployed by the function Terraform module.")
    print("If this is not what you expected, you probably need to run the function code deployment pipeline.")
    return
